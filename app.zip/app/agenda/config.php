<?php
//nome do site
$site = '127.0.0.1/agenda/';

//nome do banco de dados
$database = 'agenda';

$connection = mysqli_connect('10.1.1.10:3306','leo','supersenha',$database);
// Check connection
if (mysqli_connect_errno())
  {
  echo 'Failed to connect to MySQL: ' . mysqli_connect_error();
  }

mysqli_select_db($connection,$database);

?>
