<?php
//session_start();
if((!isset ($_SESSION['login']) == true) and (!isset ($_SESSION['senha']) == true))
{
  unset($_SESSION['login']);
  unset($_SESSION['senha']);
  header('location:login.php');
}

$logado = $_SESSION['login'];
?>
<div class="row">

  <form class="form-horizontal" name="agenda" action="dao/cad_contato.php" method="post" >
    <div class="form-group">
      <label>Nome</label>
      <input type="text" class="form-control" name="nome" autofocus required>
    </div>
    <div class="form-group">
      <label>E-mail</label>
      <input type="email" class="form-control" name="email">
    </div>
    <div class="form-group">
      <label>Telefone</label>
      <input type="tel" class="form-control" name="telefone">
    </div>
    <div class="form-group">
      <label>Ramal</label>
      <input type="tel" class="form-control" name="celular">
    </div>
    
    
    <div class="form-group">
		<label>Secretaria </label><p>
		<input type="text" list="cidade" name="cidade" autocomplete="on">
			<datalist id="cidade">
				<option value="Gestão e Desenvolvimento Humano">
				<option value="Desenvolvimento Econômico">
				<option value="Finanças">
				<option value="Meio Ambiente">
				<option value="Gabinete">
			</datalist>  
	</div>
	
	<div class="form-group">
		<label>Setor</label><p>
		<input type="text" list="estado" name="estado" autocomplete="on">
			<datalist id="estado">
				<option value="Alagoas">
				<option value="Bahia">
				<option value="Pernambuco">
				<option value="Sergipe">
			</datalist>  
	</div>

				  
	<div class="form-group">
		<label>Observações</label>
		<textarea type="textarea" class="form-control" name="observacao" placeholder="Observações"rows="3"></textarea>
	</div>
                      
                      
                      
	<button type="submit" class="btn btn-primary">Cadastrar</button>
	<button type="reset" class="btn btn-primary">Limpar</button>

	</form>
</div>