teste
<?php echo phpinfo();
